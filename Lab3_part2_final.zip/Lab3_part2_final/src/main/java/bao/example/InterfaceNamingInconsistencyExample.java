package bao.example;

interface LoginHandler {
    void login(String username, String password);
}
