package bao.example;

public final class Constants {
    public static final int MAX_USERS = 100;

    private Constants() {
        // Ngăn tạo đối tượng
    }
}
